import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class CellMeaner extends RecursiveTask<Float> {

    int[] startCorner;
    int dimension;

    public CellMeaner (int [] startAtCoord, int level) {
        startCorner = startAtCoord;
// remember that origin.depth is a count, so starts at one, while dimension is an index, so starts at zero.
        dimension = level;
    }

    @Override
    protected Float compute () {
        Float average = 0f;
        int extent = downSampler.dimensions[dimension];
        int limitedExtent = downSampler.samplingFactor;
        if (limitedExtent > extent) {
            limitedExtent = extent;
        }        
        if (dimension + 1 < downSampler.depth) {  
            for (int i = 0; i < limitedExtent; ++i) {
                int[] childCoordinate = Arrays.copyOf(startCorner, startCorner.length);
                childCoordinate[dimension] += i;
                // System.out.println("Deploying CellMeaner to " + Arrays.toString(childCoordinate) + " at depth " + (dimension + 1));
                average += ForkJoinPool.commonPool().invoke(new CellMeaner(childCoordinate, dimension + 1));
            }
        }
        else {
            for (int i = 0; i < limitedExtent; ++i) {
                int [] finalCoordinate = Arrays.copyOf(startCorner, startCorner.length);
                finalCoordinate[dimension] += i;
                average += downSampler.ReferTo(downSampler.input, finalCoordinate, -1);
            }
        }
        average /= limitedExtent;
        return average;
    }

}
