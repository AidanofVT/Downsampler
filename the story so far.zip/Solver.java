import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.Arrays;
import java.lang.Math;

public class Solver extends RecursiveAction {
    int[] parentCoordinate;
    int dimension;

    public Solver (int [] startAtCoord, int level) {
        parentCoordinate = startAtCoord;
// remember that origin.depth is a count, so starts at one, while dimension is an index, so starts at zero.
        dimension = level;
    }

    @Override
    protected void compute () {
        if (dimension < downSampler.depth) {
            int extent = downSampler.dimensions[dimension];
            for (int i = 0; i < extent; i += downSampler.samplingFactor) {
                int [] childCoordinate = Arrays.copyOf(parentCoordinate, parentCoordinate.length);
                childCoordinate[dimension] = i;
                // System.out.println("Deploying Solver to " + Arrays.toString(childCoordinate) + " at depth " + (dimension + 1));
                Solver childSolver = new Solver (childCoordinate, dimension + 1);
                ForkJoinPool.commonPool().invoke(childSolver);
            }
        }
        else {
            // String pCoordEncoded = Arrays.toString(parentCoordinate);
            // System.out.println("Deploying CellMeaner to " + pCoordEncoded + " at depth " + 0);
            float returned = ForkJoinPool.commonPool().invoke(new CellMeaner(parentCoordinate, 0));
            int result = Math.round(returned);
            int [] scaledCoordinate = Arrays.copyOf(parentCoordinate, parentCoordinate.length);
            for (int i = 0; i < scaledCoordinate.length; ++i) {
                scaledCoordinate[i] /= downSampler.samplingFactor;
            }
            downSampler.ReferTo(downSampler.output, scaledCoordinate, result);            
            // System.out.println(pCoordEncoded + " is a corner and it's average value is " + result);
        }
    }
    
}
