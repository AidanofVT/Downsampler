import java.util.Arrays;
import java.lang.reflect.Array;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

class downSampler {

    // static int [][] input = {
    //     {0,0,1,1,0,0,1,1},
    //     {0,0,0,0,1,1,0,0},
    //     {0,0,1,1,0,0,1,1},
    //     {0,0,0,0,1,1,0,0}
    // };
    static int[][][] input = new int[256][256][256];
    static Object output;
    static int minValue = 0;
// Remember that in Random, the upper bound is exclusive, so make this number one greater than you desire.
    static int maxValue = 2;
    public static int depth;
    public static int [] dimensions;
    public static int samplingFactor = 128;

    public static void main (String[] args) {
        System.out.println("Start.");
        long startTime = System.currentTimeMillis();
        depth = FindDepth(input.getClass());
        FindDimensions();
        SafetyCheck();
        CreateReceptical();
        int[] zeroPoint = new int[depth];
        FillUp(zeroPoint, 0);
        // System.out.println("Done populating array. " + (System.currentTimeMillis() - startTime) + " ellapsed.");
        ForkJoinPool.commonPool().invoke(new Solver(zeroPoint, 0));
        // SynchronousSolver(zeroPoint, 0);
        System.out.println("End after " + (System.currentTimeMillis() - startTime) + " of downSampling.");
    }

    static void CreateReceptical () {
        int [] newDimensions = Arrays.copyOf(dimensions, dimensions.length);
        for (int i = 0; i < depth; ++i) {
            int reducedValue = newDimensions[i] / samplingFactor;
            if (reducedValue < 1) {
                reducedValue = 1;
            }
            newDimensions[i] = reducedValue;
        }        
        output = Array.newInstance(int.class, newDimensions);
    }

    static void FillUp (int[] startCorner, int dimension) {
        int extent = dimensions[dimension];
        if (dimension + 1 < depth) {  
            for (int i = 0; i < extent; ++i) {
                int[] childCoordinate = Arrays.copyOf(startCorner, startCorner.length);
                childCoordinate[dimension] += i;
                FillUp(childCoordinate, dimension + 1);
            }
        }
        else {
            Random random = new Random();
            for (int i = 0; i < extent; ++i) {
                int [] finalCoordinate = Arrays.copyOf(startCorner, startCorner.length);
                finalCoordinate[dimension] += i;
                ReferTo(input, finalCoordinate, random.nextInt(maxValue) + minValue);
            }
        }
    }

    static int FindDepth(Class<?> type) {
        if (type.getComponentType() == null) {
            return 0;
        } else {
            return FindDepth(type.getComponentType()) + 1;
        }
    }

    static void FindDimensions () {
        dimensions = new int[depth];
        Object thisLevel = input;
        int i = 0;        
        Class<?> type;
        while (i < depth) {
            type = thisLevel.getClass().getComponentType();
            if (type != null){
                dimensions[i] = Array.getLength(thisLevel);
                if (type != int.class) {
                    thisLevel = ((Object[]) thisLevel)[0];
                    ++i;
                }
                else {
                    break;
                }
            }
        }        
    }

    // This was lifted from the web:
    static boolean IsPowerOfTwo(int n) { 
        return (int)(Math.ceil((Math.log(n) / Math.log(2))))  
            == (int)(Math.floor(((Math.log(n) / Math.log(2))))); 
    } 

    public static int ReferTo (Object theArray, int[] coordinate, int setTo) {
        if (depth == 1) {
            return ((int[])theArray)[coordinate[0]];
        }
        else  {
            int level = 0;
            Object [] listLevelX = (Object[]) theArray;
            for (; level < depth - 2; ++level) {
                listLevelX = (Object[]) listLevelX[coordinate[level]];
            }
            int[] arrayOfInts = (int[]) listLevelX[coordinate[level]];
            if (setTo != -1) {
                arrayOfInts[coordinate[level + 1]] = setTo;

            }
            return arrayOfInts[coordinate[level + 1]];
        }
    }

    static void SafetyCheck () {
        // System.out.println("This is an array with " + depth + " dimensions.");
        String dimensionsList = "The dimensions are ";
        for (int i = 0; i < depth; ++i) {
            int inQuestion = dimensions[i];
            if (inQuestion % 2 != 0 && inQuestion != 1) {
                throw new IllegalArgumentException("Abort! All dimensions of the starting array must either be one or a multiple of 2.");
            }
            dimensionsList += inQuestion + ", ";
        }
        System.out.println(dimensionsList.substring(0, dimensionsList.length() - 1));
        if (IsPowerOfTwo(samplingFactor) == false) {
            throw new IllegalArgumentException("Abort! The sampling factor must be a power of 2.");
        }
    }

    static Float SynchronousCellMeaner (int[] startCorner, int dimension) {
        Float average = 0f;
        int extent = dimensions[dimension];
        int limitedExtent = samplingFactor;
        if (limitedExtent > extent) {
            limitedExtent = extent;
        }        
        if (dimension + 1 < depth) {  
            for (int i = 0; i < limitedExtent; ++i) {
                int[] childCoordinate = Arrays.copyOf(startCorner, startCorner.length);
                childCoordinate[dimension] += i;
                // System.out.println("Deploying CellMeaner to " + Arrays.toString(childCoordinate) + " at depth " + (dimension + 1));
                average += SynchronousCellMeaner(childCoordinate, dimension + 1);
            }
        }
        else {
            for (int i = 0; i < limitedExtent; ++i) {
                int [] finalCoordinate = Arrays.copyOf(startCorner, startCorner.length);
                finalCoordinate[dimension] += i;
                average += ReferTo(input, finalCoordinate, -1);
            }
        }
        average /= limitedExtent;
        return average;
    } 

    static void SynchronousSolver (int[] parentCoordinate, int dimension) {
// This function exists only to test whether the multithreaded ForkJoins are working.
        if (dimension < depth) {
            int extent = dimensions[dimension];
            for (int i = 0; i < extent; i += samplingFactor) {
                int [] childCoordinate = Arrays.copyOf(parentCoordinate, parentCoordinate.length);
                childCoordinate[dimension] = i;
                SynchronousSolver(childCoordinate, dimension + 1);
            }
        }
        else {
            // String pCoordEncoded = Arrays.toString(parentCoordinate);
            // System.out.println("Deploying CellMeaner to " + pCoordEncoded + " at depth " + 0);
            float returned = SynchronousCellMeaner(parentCoordinate, 0);
            int result = Math.round(returned);
            int [] scaledCoordinate = Arrays.copyOf(parentCoordinate, parentCoordinate.length);
            for (int i = 0; i < scaledCoordinate.length; ++i) {
                scaledCoordinate[i] /= samplingFactor;
            }
            ReferTo(output, scaledCoordinate, result);            
            // System.out.println(pCoordEncoded + " is a corner and it's average value is " + result);
        }
    }
}